CREATE TRIGGER account_event
  AFTER UPDATE
  ON account
  FOR EACH ROW
  begin
   if NEW.use_status !=OLD.use_status
   then
     INSERT INTO socket_event(event_type,event_key,event_status)
     VALUES(3,OLD.empno,0);
   end if;
end;

