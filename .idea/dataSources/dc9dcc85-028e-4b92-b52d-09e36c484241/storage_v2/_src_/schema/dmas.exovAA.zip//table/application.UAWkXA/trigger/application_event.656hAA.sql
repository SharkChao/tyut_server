CREATE TRIGGER application_event
  AFTER UPDATE
  ON application
  FOR EACH ROW
  begin
   if NEW.app_status !=OLD.app_status
   then
     INSERT INTO socket_event(event_type,event_key,event_status)
     VALUES(2,OLD.app_key,0);
   end if;
end;

