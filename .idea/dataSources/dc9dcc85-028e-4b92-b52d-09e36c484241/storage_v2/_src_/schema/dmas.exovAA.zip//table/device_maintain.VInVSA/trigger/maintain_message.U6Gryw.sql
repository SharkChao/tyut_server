CREATE TRIGGER maintain_message
  AFTER INSERT
  ON device_maintain
  FOR EACH ROW
  begin
      INSERT INTO message(message_type,message_status,message_title,message_content,message_date)
      VALUES(1,0,'设备报修',NEW.to_maintain_info,now());
end;

