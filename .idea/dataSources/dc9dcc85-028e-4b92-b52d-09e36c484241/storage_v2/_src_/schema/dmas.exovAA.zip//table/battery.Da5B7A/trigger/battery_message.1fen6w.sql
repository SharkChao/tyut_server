CREATE TRIGGER battery_message
  AFTER INSERT
  ON battery
  FOR EACH ROW
  begin
   if NEW.level <=20
   then
      select COUNT(id) into @rows from message where model_IMEI=NEW.model_IMEI and message_type=0 and message_title='低电量警报';
      if  @rows=0    then
         INSERT INTO message(message_type,message_status,message_title,message_content,message_date,app_key,model_IMEI)
         VALUES(0,0,'低电量警报','电量低于20%,请及时充电',now(),NEW.app_key,NEW.model_IMEI);
     end if;
   elseif NEW.level >20 and NEW.level<=100
   then
     DELETE FROM message WHERE model_IMEI=NEW.model_IMEI and message_type=0 and message_title='低电量警报';
   end if;
end;

