CREATE TRIGGER device_event
  AFTER UPDATE
  ON device
  FOR EACH ROW
  begin
   if NEW.model_status !=OLD.model_status
   then
     INSERT INTO socket_event(event_type,event_key,event_status)
     VALUES(1,OLD.model_IMEI,0);
   end if;
end;

