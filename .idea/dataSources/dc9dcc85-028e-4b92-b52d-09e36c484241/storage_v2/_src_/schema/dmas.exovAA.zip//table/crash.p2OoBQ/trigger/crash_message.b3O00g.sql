CREATE TRIGGER crash_message
  AFTER INSERT
  ON crash
  FOR EACH ROW
  begin
     if LENGTH(NEW.throwable_message)>5
     then
     INSERT INTO message(message_type,message_status,message_title,message_content,message_date,app_key,model_IMEI)
     VALUES(2,0,'系统异常',NEW.throwable_message,now(),NEW.app_key,NEW.model_IMEI);
    end if;
end;

